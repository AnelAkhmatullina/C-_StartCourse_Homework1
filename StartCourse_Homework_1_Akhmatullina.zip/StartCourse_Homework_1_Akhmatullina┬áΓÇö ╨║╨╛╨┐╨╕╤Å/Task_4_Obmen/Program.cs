﻿using System;

namespace Task_4_Obmen
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Задача 4А"); //с третьей переменной

            Console.WriteLine("Введите значение числа a:");
            int a = int.Parse(Console.ReadLine()); // Присваиваем начальное значение a

            Console.WriteLine("Введите значение числа b:");
            int b = int.Parse(Console.ReadLine()); // Присваиваем начальное значение b

           
            int t = a;        // В t запоминаем значение a
            a = b;           // В a записываем b
            b = t;           // В b записываем сохраненное a 

            Console.WriteLine($"a равно {a}");
            Console.WriteLine($"b равно {b}");

            Console.WriteLine(); 
            Console.ReadKey();



            Console.WriteLine("Задача 4Б"); // без третьей переменной 

            Console.WriteLine("Введите значение числа c:");
            int c = int.Parse(Console.ReadLine()); 

            Console.WriteLine("Введите значение числа d:");
            int d = int.Parse(Console.ReadLine()); 

            Console.WriteLine($"c равно {d}");
            Console.WriteLine($"d равно {c}");

            Console.WriteLine(); 
            Console.ReadKey();



            Console.WriteLine("Задача 4Б(2)"); // без третьей переменной 

            Console.WriteLine("Введите значение числа a:");
            int A = int.Parse(Console.ReadLine());  

            Console.WriteLine("Введите значение числа b:");
            int B = int.Parse(Console.ReadLine()); 

            A = A + B;  // ПОДСКАЗАЛИ РЕШЕНИЕ, НО САМА БЫ НЕ ДОГАДАЛАСЬ, ПОЧЕМУ НЕЛЬЗЯ ПРОСТО ПРЕДЫДУЩЕЕ РЕШЕНИЕ ИСПОЛЬЗОВАТЬ?   
            B = A - B;
            A = A - B;
            Console.WriteLine($"a равно {A}\n b равно {B}");
            Console.ReadKey();  


        } 
         

    }
}

