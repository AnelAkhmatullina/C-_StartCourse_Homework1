﻿using System;

namespace Task_3_AtoB_distance
{

    class Program
    {
        static void Main(string[] args)
        {
            NewMethod();

        }

        private static void NewMethod()
        {
            Console.WriteLine("Введите значение координаты X1");
            double a = double.Parse(Console.ReadLine());

            Console.WriteLine("Введите значение координаты Y1");
            double b = double.Parse(Console.ReadLine());

            Console.WriteLine("Введите значение координаты X2");
            double c = double.Parse(Console.ReadLine());

            Console.WriteLine("Введите значение координаты Y2");
            double d = double.Parse(Console.ReadLine());



            Console.WriteLine($"Расстояние между координатами равно: {(Math.Sqrt(Math.Pow(c - a, 2) + Math.Pow(d - b, 2))):F2}");
            Console.ReadKey();
        }
    }
}





