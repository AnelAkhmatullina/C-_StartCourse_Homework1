﻿using System;

namespace Task_1_Anketa
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Анкета");
            Console.WriteLine("Как Вас зовут?");
            String name = Console.ReadLine();

            Console.WriteLine("Здравствуйте, " + name + "!");

            Console.WriteLine("Ваша фамилия?");
            String surname = Console.ReadLine();

            Console.WriteLine(name + ",сколько Вам лет?");
            String age = Console.ReadLine();

            Console.WriteLine("Ваш рост: ");
            String height = Console.ReadLine();

            Console.WriteLine("Ваш вес: ");
            String weight = Console.ReadLine();


            //1. Склеивание:
            Console.WriteLine("Анкета№1: " + name + " " + surname + ". Возраст: " + age + ". Рост: " + height + ". Вес: " + weight + ".");

            // 2. Форматированный вывод:
            Console.WriteLine("Анкета№1: {0} {1}. Возраст: {2}. Рост: {3}. Вес: {4}.", name, surname, age, height, weight);

            // 3. Вывод со знаком $ 
            Console.WriteLine($"Анкета№1: {name} {surname}. Возраст: {age}. Рост: {height}. Вес: {weight}.");

            Console.WriteLine("Благодарим за заполнение анкеты! ");
            Console.ReadLine();
        }
    }
}


