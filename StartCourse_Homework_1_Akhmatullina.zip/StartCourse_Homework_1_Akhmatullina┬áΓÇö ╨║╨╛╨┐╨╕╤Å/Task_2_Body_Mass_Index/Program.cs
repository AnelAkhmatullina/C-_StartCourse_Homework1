﻿using System;

namespace Task_2_Body_Mass_Index
{
    class Program
    {
        static void Main(string[] args)
        {
            double m;
            double h;

            Console.WriteLine("Введите свой вес(кг):");
            m = double.Parse(Console.ReadLine()); 

            Console.WriteLine("Введите свой рост(см):");
            h = double.Parse(Console.ReadLine());

            double imd;
            imd = m / ((h/100) * (h/100));

            Console.WriteLine($"Индекс массы тела равен: {imd:F2}"); 

            if (imd <= 18.5)
            {
                Console.WriteLine("У вас недостаток массы тела.");
                Console.ReadLine();
            }
            else if (imd > 18.5 || imd < 25)
            {
                Console.WriteLine("У вас нормальный вес");
                Console.ReadLine();
            }

            else
            {
                Console.WriteLine("Рекомендуется сбросить вес");
                Console.ReadLine(); 
            } 

        }
    }
}
