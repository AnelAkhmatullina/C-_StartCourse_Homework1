﻿using System;

namespace Task_5_6_in_the_center
{
    public class PersonalAssistants 
    {
        public static void PrintInCenter(string text)
        {
            Console.SetCursorPosition((Console.WindowWidth - text.Length) / 2, Console.WindowHeight / 2 - 1);
            Console.WriteLine(text);
        }

        public static void Pause()
        {
            Console.ReadKey();
        }        
        
    }


    class Program
    {
        static void Main(string[] args)
        {
            PersonalAssistants.PrintInCenter($"Анель Ахматуллина, г.Астана");
            PersonalAssistants.Pause(); 

        }
    }


}  

